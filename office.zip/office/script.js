let records = JSON.parse(localStorage.getItem("records")) || [];
const dropdownOptions = JSON.parse(localStorage.getItem("dropdownOptions")) || {
  unit: ["HR", "Finance", "IT"],
  billType: ["Travel", "Supplies"],
  status: ["Pending", "Approved", "Rejected"]
};

const updateTable = () => {
  const tbody = document.querySelector("#recordsTable tbody");
  tbody.innerHTML = "";
  records.forEach((rec, index) => {
    tbody.innerHTML += `
      <tr>
        <td>${rec.mailNo}</td>
        <td>${rec.auditor}</td>
        <td>${rec.unit}</td>
        <td>${rec.billType}</td>
        <td>${rec.status}</td>
        <td>${rec.actionDate}</td>
        <td>
          <button class="btn btn-sm btn-warning" onclick="editRecord(${index})"><i class="fas fa-edit"></i></button>
          <button class="btn btn-sm btn-danger" onclick="deleteRecord(${index})"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`;
  });
  localStorage.setItem("records", JSON.stringify(records));
  updateCharts();
};

document.getElementById("recordForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const record = {
    mailNo: mailNo.value,
    auditor: auditor.value,
    unit: unit.value,
    billType: billType.value,
    status: status.value,
    actionDate: actionDate.value,
  };
  const idx = editIndex.value;
  if (idx) records[idx] = record;
  else records.push(record);
  this.reset();
  $("#recordModal").modal("hide");
  updateTable();
});

const editRecord = (index) => {
  const r = records[index];
  editIndex.value = index;
  mailNo.value = r.mailNo;
  auditor.value = r.auditor;
  unit.value = r.unit;
  billType.value = r.billType;
  status.value = r.status;
  actionDate.value = r.actionDate;
  $("#recordModal").modal("show");
};

const deleteRecord = (index) => {
  if (confirm("Are you sure?")) {
    records.splice(index, 1);
    updateTable();
  }
};

document.getElementById("exportBtn").addEventListener("click", () => {
  const ws = XLSX.utils.json_to_sheet(records);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Data");
  XLSX.writeFile(wb, "records.xlsx");
});

document.getElementById("importBtn").addEventListener("click", () => {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".xlsx";
  input.onchange = (e) => {
    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      records = XLSX.utils.sheet_to_json(sheet);
      updateTable();
    };
    reader.readAsArrayBuffer(e.target.files[0]);
  };
  input.click();
});

document.getElementById("printBtn").addEventListener("click", () => window.print());

const updateCharts = () => {
  const statusData = {}, unitData = {};
  records.forEach(r => {
    statusData[r.status] = (statusData[r.status] || 0) + 1;
    unitData[r.unit] = (unitData[r.unit] || 0) + 1;
  });
  new Chart(statusChart, {
    type: "pie",
    data: {
      labels: Object.keys(statusData),
      datasets: [{ data: Object.values(statusData), backgroundColor: ["#28a745", "#ffc107", "#dc3545"] }]
    }
  });
  new Chart(unitChart, {
    type: "bar",
    data: {
      labels: Object.keys(unitData),
      datasets: [{ data: Object.values(unitData), backgroundColor: "#007bff" }]
    }
  });
};

function populateDropdown(id) {
  const select = document.getElementById(id);
  select.innerHTML = "";
  dropdownOptions[id].forEach(opt => {
    const o = document.createElement("option");
    o.value = o.innerText = opt;
    select.appendChild(o);
  });
}

["unit", "billType", "status", "filterUnit", "filterStatus"].forEach(populateDropdown);

function openDropdownModal(field) {
  document.getElementById("dropdownField").value = field;
  document.getElementById("newDropdownItem").value = "";
  const list = document.getElementById("dropdownItemsList");
  list.innerHTML = "";
  dropdownOptions[field].forEach((item, i) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `${item}<button class="btn btn-sm btn-danger" onclick="deleteDropdownItem('${field}', ${i})"><i class="fas fa-trash"></i></button>`;
    list.appendChild(li);
  });
  $('#dropdownModal').modal('show');
}

function deleteDropdownItem(field, index) {
  dropdownOptions[field].splice(index, 1);
  localStorage.setItem("dropdownOptions", JSON.stringify(dropdownOptions));
  openDropdownModal(field);
  populateDropdown(field);
}

document.getElementById("addDropdownItemBtn").addEventListener("click", () => {
  const field = dropdownField.value;
  const val = newDropdownItem.value.trim();
  if (val && !dropdownOptions[field].includes(val)) {
    dropdownOptions[field].push(val);
    localStorage.setItem("dropdownOptions", JSON.stringify(dropdownOptions));
    openDropdownModal(field);
    populateDropdown(field);
  }
});

updateTable();